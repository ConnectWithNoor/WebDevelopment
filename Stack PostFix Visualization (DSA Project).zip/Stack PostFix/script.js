class Stack 
{ 
    constructor() 
    { 
        this.items = []; 
    } 

    push(element) 
    { 
        this.items.push(element); 
    } 

    isEmpty() 
    { 
        return this.items.length == 0; 
    } 

    topEle() 
    {  
        return this.items[this.items.length - 1]; 
    } 

    pop() 
    { 
        if (this.isEmpty() == false)
            if(this.topEle() == '(')
                this.items.length=this.items.length-1;
            else
            {
                //console.log(this.topEle());
                //this.items.length=this.items.length-1;
                var post = document.getElementById('postfix').value;
                post = post + this.items.pop(); 
                document.getElementById('postfix').value = post;
            }
        return "Underflow";         
    } 

    printStack() 
    { 
        var post = document.getElementById('postfix').value;
         
        var str = ""; 
        for (var i=this.items.length-1 ; i>=0  ; i--) 
            str += this.items[i]; 
        post = post + str;
        return post;
    } 

    Prec(ch)
    {
        switch(ch)
        {
            case '+':
            case '-':
                return 1;
            case '*': 
            case '/': 
            case '%':
                return 2;   
            case '^':
                return 3;               
            default:
                return -1;
        }
    }
    postFix(exp)
    { 
        for(var i = 0; i < exp.length ; i++)
        {
            var c = exp[i];
            if((c>='0' && c<='9') || (c>='A' && c<='Z') || (c>='a' && c<='z'))
            {
                //console.log(c); 
                var post = document.getElementById('postfix').value;
                post = post + c; 
                document.getElementById('postfix').value = post;
            }
            else if(c == '(')
            {
                this.push(c);
            }
        
            else if(c == ')')
            {
                while(this.topEle() != '(')
                {
                    this.pop();                
                }
                this.pop();
            }
            else
            {
                if(this.isEmpty() == true)
                {
                    this.push(c);
                }
            
                else if(this.topEle() == '(')
                {
                    this.push(c);
                }
            
                else if( this.Prec(c) > this.Prec(this.topEle()) )
                {
                    this.push(c);
                }
            
                else
                {
                    this.pop();
                    this.push(c);
                }
            }
        }
    }
} 


function convert(e){
    document.getElementById('postfix').value = "";
    var x = document.getElementById('infix').value;
    var stack = new Stack();
    stack.postFix(x);
    document.getElementById('postfix').value = stack.printStack();
   // document.getElementById('postfix').value = x;
}