const canvas = document.querySelector('canvas');
const draw = canvas.getContext('2d');
const arrow = canvas.getContext('2d');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

draw.beginPath();               // stack box
draw.moveTo(550,150);
draw.lineTo(550, 650);
draw.lineTo(900,650);
draw.lineTo(900,150);               

draw.strokeStyle = "#1935E8";
draw.strokeRect(1300,80,150,150);   //top counter box

draw.font = "72px Arial";           //top Counter initial 
draw.fillText("-1", 1335,185);
draw.stroke();

arrow.font = "26px Arial";
arrow.fillText("Top Counter", 1300, 260);   //top text

draw.strokeStyle = "#1935E8";
draw.strokeRect(100,80,150,150);   //Element box

arrow.font = "28px Arial";
arrow.fillText("Element", 120, 260);   //Element text

draw.stroke();

arrow.beginPath();                  // arrow 
arrow.moveTo(300, 650);
arrow.lineTo(450,650);
arrow.lineTo(425,625);
arrow.lineTo(450,650);
arrow.lineTo(425,675);
arrow.stroke();

console.log(canvas);

